import os
from flask import Flask, jsonify, request, session
from config import Config
from repositories.db_pool import db_pool, get_last_queries, clear_last_queries

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Register Blueprints
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.students import student_bp
    from routes.academics import academics_bp
    from routes.operations import operations_bp
    from routes.fees import fee_bp
    from routes.admissions import admissions_bp
    from routes.insights import insights_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(academics_bp)
    app.register_blueprint(operations_bp)
    app.register_blueprint(fee_bp)
    app.register_blueprint(admissions_bp)
    app.register_blueprint(insights_bp)

    @app.before_request
    def before_req():
        if not request.path.startswith("/api/inspect-sql") and not request.path.startswith("/static"):
            clear_last_queries()

    @app.context_processor
    def inject_globals():
        return {
            "current_user": {
                "user_id": session.get("user_id"),
                "username": session.get("username", "Guest"),
                "role": session.get("role", "visitor")
            },
            "is_mysql": db_pool.is_mysql,
            "db_name": Config.DB_NAME
        }

    @app.route("/api/inspect-sql")
    def inspect_sql():
        queries = get_last_queries()
        return jsonify({
            "engine": "MySQL 8.0 (InnoDB)" if db_pool.is_mysql else "Embedded Relational Engine (SIMS)",
            "database": Config.DB_NAME,
            "queries": queries,
            "count": len(queries)
        })

    return app

app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"[*] Starting SIMS Portal on http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
