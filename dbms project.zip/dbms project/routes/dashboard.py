import io
import csv
from flask import Blueprint, render_template, request, jsonify, Response, redirect, url_for, session
from routes.auth import login_required
from repositories.dashboard import DashboardRepository
from repositories.students import StudentRepository
from repositories.admissions import AdmissionsRepository
from repositories.faculty import FacultyRepository

dashboard_bp = Blueprint("dashboard", __name__)

@dashboard_bp.route("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("auth.login_view"))
    return redirect(url_for("dashboard.dashboard_view"))

@dashboard_bp.route("/dashboard")
@login_required
def dashboard_view():
    stats = DashboardRepository.get_stats()
    pending_apps = AdmissionsRepository.get_pending()
    students_data = StudentRepository.get_all(page=1, per_page=10)
    departments = FacultyRepository.get_departments()

    return render_template(
        "dashboard.html",
        stats=stats,
        pending_apps=pending_apps[:5],
        students=students_data["items"],
        total_students=students_data["total"],
        departments=departments,
        current_page=1,
        total_pages=students_data["pages"]
    )

@dashboard_bp.route("/api/dashboard/stats")
@login_required
def api_stats():
    stats = DashboardRepository.get_stats()
    return jsonify(stats)

@dashboard_bp.route("/api/dashboard/chart")
@login_required
def api_chart():
    year = request.args.get("year", 2026, type=int)
    chart_data = DashboardRepository.get_monthly_chart(year)
    return jsonify(chart_data)

@dashboard_bp.route("/api/dashboard/export-students")
@login_required
def export_students_csv():
    dept_id = request.args.get("dept_id", None, type=int)
    status = request.args.get("status", None)
    search = request.args.get("search", None)

    # Fetch all matching without pagination limit (up to 2000)
    data = StudentRepository.get_all(search=search, dept_id=dept_id, status=status, per_page=2000)
    students = data["items"]

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Roll No", "First Name", "Last Name", "Email", "Phone", "Department", "Semester", "Status", "Admission Date", "Average Marks"])

    for s in students:
        writer.writerow([
            s["roll_no"], s["first_name"], s["last_name"], s["email"],
            s["phone"], s["dept_code"], s["current_semester"], s["status"],
            s["admission_date"], s["average_marks"]
        ])

    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=sims_students_export.csv"}
    )

