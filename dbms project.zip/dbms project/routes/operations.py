import datetime
from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from routes.auth import login_required, role_required
from repositories.enrollments import EnrollmentRepository
from repositories.attendance import AttendanceRepository
from repositories.results import ResultRepository
from repositories.courses import CourseRepository
from repositories.students import StudentRepository

operations_bp = Blueprint("operations", __name__)

# ============================================================================
# ENROLLMENTS
# ============================================================================
@operations_bp.route("/enrollments")
@login_required
def enrollments_view():
    offering_id = request.args.get("offering_id", None, type=int)
    student_id = request.args.get("student_id", None, type=int)
    enrollments = EnrollmentRepository.get_all(offering_id=offering_id, student_id=student_id)
    offerings = CourseRepository.get_offerings()
    students = StudentRepository.get_all(per_page=100)["items"]

    return render_template(
        "operations/enrollments.html",
        enrollments=enrollments,
        offerings=offerings,
        students=students,
        offering_id=offering_id,
        student_id=student_id
    )

@operations_bp.route("/api/enrollments/enroll", methods=["POST"])
@login_required
def enroll_student_api():
    data = request.get_json() or request.form
    student_id = int(data.get("student_id"))
    offering_id = int(data.get("offering_id"))

    res = EnrollmentRepository.enroll_student(student_id, offering_id)
    if res["status_code"] == 200:
        return jsonify({"success": True, "message": res["message"]})
    else:
        return jsonify({"success": False, "message": res["message"]}), res["status_code"]

# ============================================================================
# ATTENDANCE
# ============================================================================
@operations_bp.route("/attendance")
@login_required
def attendance_view():
    offerings = CourseRepository.get_offerings()
    default_off_id = offerings[0]["offering_id"] if offerings else 1
    offering_id = request.args.get("offering_id", default_off_id, type=int)
    class_date = request.args.get("class_date", datetime.date.today().isoformat())

    roster = AttendanceRepository.get_class_roster(offering_id, class_date)
    current_offering = CourseRepository.get_offering_by_id(offering_id)
    summary = AttendanceRepository.get_summary_by_offering(offering_id)

    return render_template(
        "operations/attendance.html",
        offerings=offerings,
        current_offering=current_offering,
        offering_id=offering_id,
        class_date=class_date,
        roster=roster,
        summary=summary
    )

@operations_bp.route("/api/attendance/mark", methods=["POST"])
@login_required
def mark_attendance_api():
    data = request.get_json()
    offering_id = int(data.get("offering_id"))
    class_date = data.get("class_date")
    records = data.get("records", [])

    try:
        res = AttendanceRepository.save_batch(offering_id, class_date, records)
        return jsonify({"success": True, "message": f"Successfully recorded attendance for {res['count']} students."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 400

# ============================================================================
# RESULTS & GRADEBOOK
# ============================================================================
@operations_bp.route("/results")
@login_required
def results_view():
    offerings = CourseRepository.get_offerings()
    default_off_id = offerings[0]["offering_id"] if offerings else 1
    offering_id = request.args.get("offering_id", default_off_id, type=int)

    exams = ResultRepository.get_exams_by_offering(offering_id)
    default_exam_id = exams[0]["exam_id"] if exams else None
    exam_id = request.args.get("exam_id", default_exam_id, type=int)

    gradebook = []
    current_exam = None
    if exam_id:
        gradebook = ResultRepository.get_gradebook_for_exam(exam_id)
        current_exam = ResultRepository.get_exam_by_id(exam_id)

    current_offering = CourseRepository.get_offering_by_id(offering_id)

    return render_template(
        "operations/results.html",
        offerings=offerings,
        current_offering=current_offering,
        offering_id=offering_id,
        exams=exams,
        exam_id=exam_id,
        current_exam=current_exam,
        gradebook=gradebook
    )

@operations_bp.route("/api/results/save", methods=["POST"])
@login_required
def save_result_api():
    data = request.get_json() or request.form
    exam_id = int(data.get("exam_id"))
    enrollment_id = int(data.get("enrollment_id"))
    marks_obtained = float(data.get("marks_obtained"))

    try:
        res_id = ResultRepository.save_result(exam_id, enrollment_id, marks_obtained)
        return jsonify({"success": True, "message": "Mark saved successfully.", "result_id": res_id})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 400

