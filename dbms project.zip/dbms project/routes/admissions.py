from flask import Blueprint, request, jsonify, session
from routes.auth import login_required, role_required
from repositories.admissions import AdmissionsRepository

admissions_bp = Blueprint("admissions", __name__)

@admissions_bp.route("/api/admissions/pending")
@login_required
def get_pending():
    apps = AdmissionsRepository.get_pending()
    return jsonify(apps)

@admissions_bp.route("/api/admissions/approve", methods=["POST"])
@login_required
@role_required("admin", "faculty")
def approve():
    data = request.get_json() or request.form
    app_id = int(data.get("application_id"))
    reviewer_id = session.get("faculty_id") or 1

    res = AdmissionsRepository.approve_admission(app_id, reviewer_id=reviewer_id)
    if res["status_code"] == 200:
        return jsonify({"success": True, "message": res["message"], "roll_no": res.get("roll_no")})
    else:
        return jsonify({"success": False, "message": res["message"]}), res["status_code"]

@admissions_bp.route("/api/admissions/reject", methods=["POST"])
@login_required
@role_required("admin", "faculty")
def reject():
    data = request.get_json() or request.form
    app_id = int(data.get("application_id"))
    reviewer_id = session.get("faculty_id") or 1

    res = AdmissionsRepository.reject_admission(app_id, reviewer_id=reviewer_id)
    return jsonify({"success": True, "message": res["message"]})

