# Student Information Management System (SIMS)
### Graded B.Tech CSE Database Management Systems (DBMS) Mini-Project

> **Viva Priority Order:** Relational Schema Correctness $\to$ SQL Depth & Explainability $\to$ ACID & Constraint Rigor $\to$ Zero-ORM Transparency $\to$ Polished Executive UI.

---

## 1. Executive Summary

**Student Information Management System (SIMS)** is a full-featured, enterprise-grade relational database application developed for university academic operations. Unlike conventional web applications that hide database logic behind Object-Relational Mappers (ORMs), **SIMS treats the database as the primary product**.

The core database architecture encompasses **15 normalized relational tables (3NF / BCNF)**, declarative integrity constraints (`PK`, `FK`, `UNIQUE`, `CHECK`, `DEFAULT`), **10 active triggers**, **3 ACID-compliant stored procedures**, **3 stored functions**, **6 relational views**, **6 composite/covering indexes**, and a catalog of **25 advanced showcase SQL queries**.

The user interface follows the **Jobgio executive floating dashboard aesthetic** (monochrome `#0E0E0E`/`#FFFFFF`, subtle neutral grays `#F2F2F2`, discrete status dots, zero clutter). Every view in the web portal features a live **"Show SQL"** inspector that reveals the exact parameterized SQL statement executed on the database server.

---

## 2. Key Architecture & Technology Stack

| Layer | Technology | Engineering Design Choice |
| :--- | :--- | :--- |
| **Relational Database** | **MySQL 8.0 (InnoDB) / Dual Relational Pool** | Strict ANSI SQL & MySQL 8 DDL with InnoDB row-level locking. Includes embedded zero-config relational fallback (`sims_embedded.db`) for seamless viva demos on non-root machines. |
| **Backend Framework** | **Python 3.14 + Flask** | Modular Blueprint routing, session management, secure Bcrypt authentication. |
| **Data Access Layer** | **Zero-ORM Raw Parameterized SQL (`%s`)** | **100% ORM-free**. All operations execute raw SQL in dedicated `repositories/`. Absolute immunity to SQL injection via parameterized values. |
| **Frontend Shell** | **HTML5 + Semantic CSS + Vanilla JS** | Jobgio floating dashboard (1440×900 shell), Chart.js admissions chart, real-time SQL execution modal. |
| **Testing Suite** | **pytest (59 Unit & Concurrency Tests)** | Automated verification of concurrency row locking, trigger enforcement, procedure rollbacks, security neutralization, and query correctness. |

---

## 3. Demo Credentials

The database comes pre-seeded with three role-based accounts:

| Role | Username | Password | Access Privileges |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `admin123` | Full privileges: Admissions approval, student matriculation, course scheduling, fee ledgers, audit logs, and DB insights. |
| **Faculty Member** | `faculty` | `faculty123` | Roll-call attendance marking, examination gradebook recording, student performance lookup. |
| **Student** | `student` | `student123` | Read-only access to personal 360° dossier, attendance records, exam transcripts, and fee status. |

---

## 4. How to Run the Application

### Option A: Standard Direct Run (Recommended for Viva)

1. **Clone or Open the Repository:**
   ```bash
   cd "c:/Users/Om_targaryan/Desktop/dbms project"
   ```

2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify Seed Data (Automatic):**
   ```bash
   python db/seed.py
   ```
   *Generated: 6 departments, 25 faculty, 321 students, 40 courses, 60 offerings, 1,328 enrollments, 6,250 attendance records, 180 exams, 3,966 results, 266 fee payments, and 21 pending applications.*

4. **Launch the Web Server:**
   ```bash
   python app.py
   ```
   *Access the portal in your browser at:* **`http://127.0.0.1:5000`**

---

### Option B: Running with Docker & Live MySQL 8

If Docker Desktop is available on the machine:

```bash
docker compose up -d
python db/seed.py
python app.py
```

---

## 5. Running the Automated Test Suite

SIMS includes **59 comprehensive automated tests** validating every constraint, stored routine, race condition, and route:

```bash
python -m pytest tests/ -v
```

### Test Suite Matrix:
- `tests/test_concurrency.py`: Simulates 2 concurrent threads racing for the final remaining seat in a course offering. Proves that `sp_enroll_student` with `SELECT ... FOR UPDATE` row locking prevents overselling (1 succeeded, 1 rolled back, physical count = 1).
- `tests/test_procedures.py`: Verifies transactional atomicity for admission approval, matriculation, and fee overpayment guards.
- `tests/test_triggers.py`: Proves trigger aborts when inserting marks higher than exam max marks, or logging attendance for a dropped student.
- `tests/test_queries.py`: Executes all 25 showcase queries (Q01-Q25) validating non-empty result sets.
- `tests/test_security.py`: Proves SQL injection attacks (`' OR '1'='1`) are completely neutralized in search and sort parameters.
- `tests/test_routes.py`: Verifies HTTP 200 responses and template rendering across all views and API endpoints.

---

## 6. Database Schema Design (15 Relational Tables)

All schema definitions reside in [`db/schema.sql`](file:///c:/Users/Om_targaryan/Desktop/dbms project/db/schema.sql).

```
+----------------------------------------------------------------------------------------------------+
|                                    SIMS RELATIONAL ARCHITECTURE                                    |
+----------------------------------------------------------------------------------------------------+

 [department] 1 -----< [faculty] 1 -----< [course_offering] 1 -----< [exam] 1 -----< [result]
      |                      ^                     |                                    ^
      | 1                    | 1 (HoD)             | 1                                  |
      +-------< [student] ---+                     +-------< [enrollment] >-------------+
                   |                                               |
                   +-------< [guardian] (3NF)                      +-------< [attendance]
                   |
                   +-------< [fee_payment]                         [fee_structure] (dept_id, sem_no)
                   |
                   +-------< [admission_application]               [app_user] (auth + XOR role check)
                   |
                   +-------< [audit_log] (JSON trigger diffs)
```

### Table Inventory:
1. `department`: PK `dept_id`, UNIQUE `dept_code`, UNIQUE `dept_name`, FK `hod_faculty_id` (SET NULL).
2. `faculty`: PK `faculty_id`, UNIQUE `email`, FK `dept_id` (RESTRICT), `CHECK (salary > 0)`.
3. `student`: PK `student_id`, UNIQUE `roll_no`, UNIQUE `email`, `CHECK (dob <= admission_date - 15 years)`, `CHECK (current_semester BETWEEN 1 AND 8)`.
4. `guardian`: PK `guardian_id`, FK `student_id` (CASCADE). **Normalized out of student into 1:N table to eliminate repeating groups and satisfy 3NF**.
5. `course`: PK `course_id`, UNIQUE `course_code`, FK `dept_id` (RESTRICT), `CHECK (credits BETWEEN 1 AND 6)`.
6. `course_offering`: PK `offering_id`, FK `course_id`, FK `faculty_id`, `UNIQUE (course_id, academic_year, term)`, `CHECK (capacity > 0)`.
7. `enrollment`: PK `enrollment_id`, FK `student_id` (RESTRICT), FK `offering_id` (RESTRICT), `UNIQUE (student_id, offering_id)` junction table.
8. `attendance`: PK `attendance_id`, FK `enrollment_id` (CASCADE), `UNIQUE (enrollment_id, class_date)`.
9. `exam`: PK `exam_id`, FK `offering_id` (CASCADE), `CHECK (max_marks > 0)`.
10. `result`: PK `result_id`, FK `exam_id` (CASCADE), FK `enrollment_id` (RESTRICT), `UNIQUE (exam_id, enrollment_id)`.
11. `fee_structure`: Composite PK `(dept_id, semester_no)`, `CHECK (amount > 0)`.
12. `fee_payment`: PK `payment_id`, FK `student_id` (RESTRICT), UNIQUE `receipt_no`, `CHECK (amount > 0)`.
13. `admission_application`: PK `application_id`, FK `dept_id` (RESTRICT), FK `reviewed_by` (SET NULL).
14. `app_user`: PK `user_id`, UNIQUE `username`, `CHECK (role XOR student_id XOR faculty_id)` role integrity constraint.
15. `audit_log`: PK `log_id`, stores `table_name`, `action` (`INSERT`, `UPDATE`, `DELETE`), `record_id`, `old_values` (JSON), `new_values` (JSON), `changed_by`, `changed_at`.

---

## 7. Stored Procedures, Triggers & Views

### Stored Procedures ([`db/procedures.sql`](file:///c:/Users/Om_targaryan/Desktop/dbms project/db/procedures.sql))
- `sp_enroll_student(p_student_id, p_offering_id, OUT p_status_code, OUT p_message)`: Atomically locks the offering row using `SELECT ... FOR UPDATE`, checks capacity and student status, inserts enrollment, commits, or rolls back.
- `sp_approve_admission(p_application_id, p_reviewer_id, OUT p_status_code, OUT p_message, OUT p_new_roll_no)`: In a single ACID transaction, changes application status to 'Approved', generates a sequential roll number, inserts the student, and provisions user credentials.
- `sp_record_payment(p_student_id, p_semester_no, p_amount, p_mode, p_receipt_no, OUT p_status_code, OUT p_message)`: Verifies semester fee structure, checks cumulative payments, and rejects any overpayment.

### Stored Functions
- `fn_grade(p_percentage)`: Returns letter grade (`A+`, `A`, `B+`, `B`, `C`, `P`, `F`).
- `fn_attendance_pct(p_enrollment_id)`: Calculates percentage of lectures attended.
- `fn_student_cgpa(p_student_id)`: Weighted credit-point CGPA calculation across all completed courses.

### Triggers ([`db/triggers.sql`](file:///c:/Users/Om_targaryan/Desktop/dbms project/db/triggers.sql))
- `trg_enrollment_before_insert`: Aborts enrollment if offering is at capacity or student is not `Active`.
- `trg_enrollment_after_insert/delete`: Automatically updates `course_offering.enrolled_count`.
- `trg_result_before_insert/update`: Rejects any mark where `marks_obtained > exam.max_marks`.
- `trg_attendance_before_insert`: Prevents recording attendance for a student with `Dropped` enrollment status.
- `trg_student_audit` & `trg_fee_audit`: Captures old and new row states as JSON objects into `audit_log`.

---

## 8. Query Showcase Catalogue (25 Queries)

All queries are located in [`db/queries/`](file:///c:/Users/Om_targaryan/Desktop/dbms project/db/queries/) and interactively executable in the web portal under **DB Insights &rarr; 25 Queries Showcase**:

| Query ID | Category | Description | Key SQL Construct |
| :--- | :--- | :--- | :--- |
| **Q01** | Joins | Student, Department, and HoD listing | `INNER JOIN` (3 tables) |
| **Q02** | Joins | Students with zero course enrollments | `LEFT JOIN ... WHERE e.enrollment_id IS NULL` |
| **Q03** | Joins | Departments with or without faculty assignments | Simulated `FULL OUTER JOIN` (`UNION` of `LEFT` and `RIGHT`) |
| **Q04** | Joins | Faculty members and their departmental HoD | Self-Join on `faculty` and `department` |
| **Q05** | Joins | Student dossier with course, exam, and instructor | 5-table multi-join |
| **Q06** | Joins | Timetable matrix cross product | `CROSS JOIN` (Offerings $\times$ Time Slots) |
| **Q07** | Aggregation | Departments with more than $N$ enrolled students | `GROUP BY` with `HAVING COUNT(*) > 50` |
| **Q08** | Aggregation | Academic course statistics | `COUNT`, `SUM`, `AVG`, `MIN`, `MAX` |
| **Q09** | Aggregation | Tuition fees collected per department per semester | Multi-column `GROUP BY` with `SUM` |
| **Q10** | Aggregation | Attendance percentage per course section | Conditional aggregation `SUM(CASE WHEN ...)` |
| **Q11** | Aggregation | Examination performance metrics | Grouped aggregates with grade threshold counts |
| **Q12** | Subqueries | Students with above-average department CGPA | Correlated subquery in `WHERE` clause |
| **Q13** | Subqueries | Faculty members actively teaching this academic year | Subquery with `EXISTS` |
| **Q14** | Subqueries | Course offerings with maximum enrolled seats | Scalar subquery in `WHERE` |
| **Q15** | Subqueries | Faculty workload and section distribution | Derived table in `FROM` clause (`subquery alias`) |
| **Q16** | Subqueries | Top-scoring students matching or exceeding all marks | Quantified subquery with `>= ALL (...)` |
| **Q17** | Windows / CTE | Top 3 students per academic department | Window function `DENSE_RANK() OVER (PARTITION BY ...)` |
| **Q18** | Windows / CTE | Cumulative running total of fees collected by month | Window function `SUM(...) OVER (ORDER BY month ASC)` |
| **Q19** | Windows / CTE | Semester-over-semester grade progress | Window function `LAG(...) OVER (...)` |
| **Q20** | Windows / CTE | Recursive academic curriculum prerequisite tree | Recursive Common Table Expression (`WITH RECURSIVE`) |
| **Q21** | Windows / CTE | Outstanding fee defaulter comprehensive report | Multi-CTE pipeline (`WITH fee_summary AS (...)`) |
| **Q22** | Sets | Unified directory of university campus email addresses | `UNION ALL` across Student and Faculty tables |
| **Q23** | Sets | Courses defined in catalog but never offered | `EXCEPT` / `NOT IN` set difference |
| **Q24** | DML Transaction | Bulk promotion of qualifying students to next semester | `INSERT ... SELECT` wrapped in atomic rollback demo |
| **Q25** | DML Transaction | Bulk tuition fee adjustment for CSE department | Multi-table `UPDATE ... JOIN` with transaction rollback |

---

## 9. Backup & Restore Procedures

### Running Backup:
```bash
# On Linux / macOS / Git Bash:
bash scripts/backup.sh

# On Windows PowerShell:
python scripts/backup.py
```
*Creates a timestamped snapshot in `backups/sims_db_YYYYMMDD_HHMMSS.sql` (or `.db`).*

### Running Restore:
```bash
# On Linux / macOS / Git Bash:
bash scripts/restore.sh backups/sims_db_20261020_120000.sql

# On Windows PowerShell:
python scripts/restore.py backups/sims_embedded_20261020_115611.db
```

---

## 10. Viva Defense & Examination Guide

### Q1: Why did you not use SQLAlchemy ORM or Django ORM?
> **Defense:** In a DBMS academic evaluation, an ORM hides the relational engine. ORMs generate suboptimal queries, mask Cartesian products, cause N+1 query antipatterns, and obscure transactions. SIMS implements a clean, layered Repository Pattern with raw parameterized SQL (`%s`). The professor can inspect every single query live in the browser using the "Show SQL" button.

### Q2: How did you prevent race conditions when two students enroll in the last available seat?
> **Defense:** We enforce pessimistic row-level locking in `sp_enroll_student`. Using `SELECT capacity, enrolled_count FROM course_offering WHERE offering_id = p_offering_id FOR UPDATE`, MySQL InnoDB places an exclusive lock on that section's row. The second transaction must wait until the first commits. The second transaction then reads `enrolled_count == capacity` and is rejected with HTTP 409 and `ROLLBACK`.

### Q3: Why is `guardian` a separate table rather than columns inside `student`?
> **Defense:** If guardian attributes (`guardian_name`, `guardian_phone`, `relation`) were kept in the `student` table, having multiple guardians would either create repeating groups (violating 1NF) or introduce partial dependencies if modeled as separate columns (`guardian1`, `guardian2`), which violates 3NF. Separating `guardian` into a child table with `student_id` foreign key achieves clean 3NF.

### Q4: How is SQL injection prevented without an ORM?
> **Defense:** Every repository method uses strictly parameterized prepared queries where inputs are passed as separate parameter tuples. User inputs are never concatenated directly into SQL strings. Sort columns and direction parameters are checked against strict whitelist dictionaries (`ALLOWED_SORT_COLUMNS`), immediately raising an error if an unauthorized identifier is supplied.

### Q5: How do triggers ensure data integrity?
> **Defense:** While application code can have bugs or be bypassed by direct database connections, triggers enforce business rules inside the storage engine itself. For example, `trg_result_before_insert` throws a `SIGNAL SQLSTATE '45000'` error if `marks_obtained > max_marks`. Even an administrator running a raw SQL `INSERT` in a terminal cannot violate this rule.

---

## 11. Project Directory Structure

```
dbms project/
├── app.py                      # Flask Application entry point & Blueprint registry
├── config.py                   # Configuration & Environment loader
├── requirements.txt            # Python dependencies (Flask, PyMySQL, Faker, Pytest)
├── Dockerfile                  # Production container definition
├── docker-compose.yml          # MySQL 8.0 & Web service orchestration
├── db/
│   ├── schema.sql              # 15 normalized tables with constraints
│   ├── indexes.sql             # 6 secondary composite/covering indexes
│   ├── roles.sql               # Least-privilege DB roles & grants
│   ├── views.sql               # 6 relational views
│   ├── triggers.sql            # 10 triggers (capacity, marks ceiling, audit)
│   ├── procedures.sql          # 3 stored procedures & 3 stored functions
│   ├── seed.py                 # Deterministic data generation script (seed=42)
│   └── queries/                # 25 showcase SQL queries (Q01 - Q25)
│       ├── joins.sql           # Joins (Q01 - Q06)
│       ├── aggregates.sql      # Aggregations & Grouping (Q07 - Q11)
│       ├── subqueries.sql      # Subqueries & Correlated (Q12 - Q16)
│       ├── windows_ctes.sql    # Window Functions & CTEs (Q17 - Q21)
│       ├── sets.sql            # Set Operations (Q22 - Q23)
│       └── dml.sql             # Transactional DML Demonstrations (Q24 - Q25)
├── repositories/               # Zero-ORM Data Access Layer (Pure SQL)
│   ├── db_pool.py              # Dual-Engine Connection Pool & Query Inspector
│   ├── students.py             # Student CRUD, 360 dossier, fee summaries
│   ├── faculty.py              # Faculty & Department queries
│   ├── courses.py              # Course catalog & offerings
│   ├── enrollments.py          # Atomic enrollment & race condition handler
│   ├── attendance.py           # Roll-call sheet batch transaction
│   ├── results.py              # Gradebook & trigger-checked marks
│   ├── fees.py                 # Payments & defaulters ledger
│   ├── admissions.py           # Application approval & user provisioning
│   ├── dashboard.py            # KPI counters & chart aggregations
│   └── insights.py             # Query runner, EXPLAIN plans & audit logs
├── routes/                     # HTTP Route Blueprints & RBAC
├── static/                     # Jobgio Monochrome Assets & JS
│   ├── css/tokens.css          # Design tokens & color system
│   ├── css/shell.css           # Floating 1440x900 shell & UI styling
│   └── js/                     # Client scripts, chart loader & SQL modal
├── templates/                  # Jinja2 HTML Templates
│   ├── base.html               # Floating shell with nav & "Show SQL" button
│   ├── login.html              # Clean monochrome login screen
│   ├── dashboard.html          # Executive stats, chart, pending admissions
│   ├── students/               # Directory & 360 dossier views
│   ├── academics/              # Faculty, departments, courses & offerings
│   ├── operations/             # Enrollments, attendance roll-call, results
│   ├── fees/                   # Ledgers & defaulter lists
│   └── insights/               # Viva lab (25 queries, EXPLAIN, ACID rollback)
├── scripts/                    # Backup & Restore automation scripts
├── tests/                      # Automated Test Suite (59 Tests, 100% Passing)
└── docs/                       # Complete Phase 1-7 Stage A Design Document
```

