import os
import sys
import pytest

# Add workspace directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from repositories.db_pool import db_pool

@pytest.fixture(scope="session")
def db():
    """Returns the shared database pool for testing."""
    return db_pool

