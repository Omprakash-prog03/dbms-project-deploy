// ============================================================================
// SIMS DASHBOARD SCRIPTS (COUNT-UP ANIMATION & JOBGIO BAR CHART)
// ============================================================================

document.addEventListener("DOMContentLoaded", () => {
    // 1. KPI Numbers 400ms Count-Up Animation
    const statElements = document.querySelectorAll(".stat-number[data-target]");
    statElements.forEach(el => {
        const target = parseInt(el.getAttribute("data-target"), 10) || 0;
        const duration = 400; // ms
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            // Ease out quad
            const currentVal = Math.floor(progress * target);
            el.textContent = currentVal.toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(update);
            } else {
                el.textContent = target.toLocaleString();
            }
        }
        requestAnimationFrame(update);
    });

    // 2. Statistics Grouped Bar Chart (Chart.js)
    const ctx = document.getElementById("statsChart");
    if (ctx) {
        fetch("/api/dashboard/chart?year=2026")
            .then(res => res.json())
            .then(data => {
                new Chart(ctx, {
                    type: "bar",
                    data: {
                        labels: data.labels,
                        datasets: [
                            {
                                label: "Admissions",
                                data: data.admissions,
                                backgroundColor: "#0E0E0E", // Ink Black
                                borderRadius: 8,
                                borderSkipped: false,
                                barPercentage: 0.55,
                                categoryPercentage: 0.5
                            },
                            {
                                label: "Enrollments",
                                data: data.enrollments,
                                backgroundColor: "#D5D5D5", // Light Gray
                                borderRadius: 8,
                                borderSkipped: false,
                                barPercentage: 0.55,
                                categoryPercentage: 0.5
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: "#0E0E0E",
                                titleColor: "#FFFFFF",
                                bodyColor: "#FFFFFF",
                                padding: 10,
                                cornerRadius: 20,
                                displayColors: false,
                                callbacks: {
                                    label: function(context) {
                                        let val = context.raw;
                                        let fmt = val >= 1000 ? (val / 1000).toFixed(1) + "K" : val;
                                        return `${context.dataset.label}: ${fmt}`;
                                    }
                                }
                            }
                        },
                        scales: {
                            x: {
                                grid: { display: false },
                                ticks: {
                                    color: "#8E8E8E",
                                    font: { family: "Plus Jakarta Sans", size: 11, weight: "600" }
                                }
                            },
                            y: {
                                border: { dash: [4, 4] },
                                grid: { color: "rgba(0, 0, 0, 0.05)" },
                                ticks: {
                                    color: "#8E8E8E",
                                    font: { family: "Plus Jakarta Sans", size: 11 },
                                    callback: function(val) {
                                        return val >= 1000 ? (val / 1000).toFixed(0) + "K" : val;
                                    }
                                }
                            }
                        }
                    }
                });
            })
            .catch(err => console.error("Error loading chart:", err));
    }

    // 3. Admission Quick Approve/Reject Action
    document.querySelectorAll(".btn-approve-app").forEach(btn => {
        btn.addEventListener("click", function() {
            const appId = this.getAttribute("data-id");
            this.disabled = true;
            this.textContent = "Processing...";

            fetch("/api/admissions/approve", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ application_id: appId })
            })
            .then(res => res.json())
            .then(res => {
                if (res.success) {
                    showToast(`Approved! Roll No: ${res.roll_no} generated and enrolled.`);
                    const item = document.getElementById(`pending-item-${appId}`);
                    if (item) {
                        item.style.opacity = "0";
                        item.style.transform = "translateX(20px)";
                        setTimeout(() => item.remove(), 250);
                    }
                } else {
                    showToast(res.message, "error");
                    this.disabled = false;
                    this.textContent = "Approve";
                }
            })
            .catch(err => {
                showToast("Network error: " + err, "error");
                this.disabled = false;
                this.textContent = "Approve";
            });
        });
    });
});

