// ============================================================================
// SIMS CLIENT APPLICATION CORE (VANILLA JS)
// ============================================================================

window.showToast = function(message, type = "success") {
    let container = document.getElementById("toast-container");
    if (!container) {
        container = document.createElement("div");
        container.id = "toast-container";
        container.className = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(10px)";
        toast.style.transition = "all 200ms ease";
        setTimeout(() => toast.remove(), 200);
    }, 3500);
};

// Global modal helpers
window.openModal = function(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.add("active");
};

window.closeModal = function(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove("active");
};

document.addEventListener("DOMContentLoaded", () => {
    // Close modal on click outside
    document.querySelectorAll(".modal-overlay").forEach(overlay => {
        overlay.addEventListener("click", (e) => {
            if (e.target === overlay) overlay.classList.remove("active");
        });
    });

    // Close on escape key
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            document.querySelectorAll(".modal-overlay.active").forEach(m => m.classList.remove("active"));
        }
    });
});

