#!/usr/bin/env bash
# ==============================================================================
# SIMS Database Backup Script (mysqldump)
# B.Tech CSE DBMS Project Backup Utility
# ==============================================================================

set -e

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-3306}"
DB_NAME="${DB_NAME:-sims_db}"
DB_USER="${DB_USER:-sims_admin}"
DB_PASSWORD="${DB_PASSWORD:-AdminPass123!}"

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="$(dirname "$0")/../backups"
BACKUP_FILE="${BACKUP_DIR}/sims_db_${TIMESTAMP}.sql"

mkdir -p "${BACKUP_DIR}"

echo "===================================================================="
echo "Starting SIMS Database Backup: ${DB_NAME} at ${TIMESTAMP}"
echo "===================================================================="

if command -v mysqldump >/dev/null 2>&1; then
  echo "Invoking mysqldump for schema, triggers, routines, and table rows..."
  MYSQL_PWD="${DB_PASSWORD}" mysqldump \
    --host="${DB_HOST}" \
    --port="${DB_PORT}" \
    --user="${DB_USER}" \
    --routines \
    --triggers \
    --events \
    --single-transaction \
    --add-drop-table \
    "${DB_NAME}" > "${BACKUP_FILE}"
  
  echo "SUCCESS: MySQL database backup created at:"
  echo "  --> ${BACKUP_FILE}"
  echo "File size: $(ls -lh "${BACKUP_FILE}" | awk '{print $5}')"
elif [ -f "$(dirname "$0")/../sims_embedded.db" ]; then
  echo "mysqldump command not found. Performing embedded SQLite snapshot backup..."
  cp "$(dirname "$0")/../sims_embedded.db" "${BACKUP_DIR}/sims_embedded_${TIMESTAMP}.db"
  echo "SUCCESS: Embedded database snapshot created at:"
  echo "  --> ${BACKUP_DIR}/sims_embedded_${TIMESTAMP}.db"
else
  echo "ERROR: Neither MySQL client nor embedded database found."
  exit 1
fi

echo "===================================================================="
echo "Backup Completed Successfully."
echo "===================================================================="

