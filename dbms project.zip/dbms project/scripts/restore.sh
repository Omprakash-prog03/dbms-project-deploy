#!/usr/bin/env bash
# ==============================================================================
# SIMS Database Restore Script (mysql client)
# B.Tech CSE DBMS Project Restore Utility
# ==============================================================================

set -e

if [ -z "$1" ]; then
  echo "Usage: $0 <path_to_backup_sql_or_db_file>"
  echo "Example: $0 backups/sims_db_20261020_120000.sql"
  exit 1
fi

RESTORE_FILE="$1"

if [ ! -f "${RESTORE_FILE}" ]; then
  echo "ERROR: Backup file '${RESTORE_FILE}' does not exist."
  exit 1
fi

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-3306}"
DB_NAME="${DB_NAME:-sims_db}"
DB_USER="${DB_USER:-sims_admin}"
DB_PASSWORD="${DB_PASSWORD:-AdminPass123!}"

echo "===================================================================="
echo "Starting SIMS Database Restore from: ${RESTORE_FILE}"
echo "Target Database: ${DB_NAME} (${DB_HOST}:${DB_PORT})"
echo "===================================================================="

if [[ "${RESTORE_FILE}" == *.sql ]]; then
  if command -v mysql >/dev/null 2>&1; then
    echo "Executing SQL restore via mysql client..."
    MYSQL_PWD="${DB_PASSWORD}" mysql \
      --host="${DB_HOST}" \
      --port="${DB_PORT}" \
      --user="${DB_USER}" \
      "${DB_NAME}" < "${RESTORE_FILE}"
    echo "SUCCESS: Database '${DB_NAME}' restored from '${RESTORE_FILE}'."
  else
    echo "ERROR: mysql client binary not found in PATH."
    exit 1
  fi
elif [[ "${RESTORE_FILE}" == *.db ]]; then
  echo "Restoring embedded database file to sims_embedded.db..."
  cp "${RESTORE_FILE}" "$(dirname "$0")/../sims_embedded.db"
  echo "SUCCESS: Embedded database successfully restored."
else
  echo "ERROR: Unrecognized backup format. Must be .sql or .db"
  exit 1
fi

echo "===================================================================="
echo "Restore Completed Successfully."
echo "===================================================================="

