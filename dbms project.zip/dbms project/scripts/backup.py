import os
import shutil
import datetime
import subprocess

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    backup_dir = os.path.join(root, "backups")
    os.makedirs(backup_dir, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # If embedded sqlite exists, copy it
    sqlite_db = os.path.join(root, "sims_embedded.db")
    if os.path.exists(sqlite_db):
        dest = os.path.join(backup_dir, f"sims_embedded_{ts}.db")
        shutil.copy2(sqlite_db, dest)
        print(f"[SUCCESS] Embedded database snapshot created: {dest}")

    # Check if mysqldump is available
    mysqldump_bin = shutil.which("mysqldump")
    if mysqldump_bin:
        dest_sql = os.path.join(backup_dir, f"sims_db_{ts}.sql")
        cmd = [
            mysqldump_bin,
            "-h", os.getenv("DB_HOST", "127.0.0.1"),
            "-P", os.getenv("DB_PORT", "3306"),
            "-u", os.getenv("DB_USER", "sims_admin"),
            f"-p{os.getenv('DB_PASSWORD', 'AdminPass123!')}",
            "--routines", "--triggers", "--events",
            os.getenv("DB_NAME", "sims_db")
        ]
        try:
            with open(dest_sql, "w", encoding="utf-8") as f:
                subprocess.run(cmd, stdout=f, check=True)
            print(f"[SUCCESS] MySQL mysqldump backup created: {dest_sql}")
        except Exception as e:
            print(f"[INFO] MySQL dump skipped: {e}")

if __name__ == "__main__":
    main()

