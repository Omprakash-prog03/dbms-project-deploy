from repositories.db_pool import db_pool
import datetime

class AttendanceRepository:
    @staticmethod
    def get_class_roster(offering_id, class_date=None):
        if not class_date:
            class_date = datetime.date.today().isoformat()
            
        sql = """
            SELECT e.enrollment_id, s.student_id, s.roll_no,
                   (s.first_name || ' ' || s.last_name) AS student_name,
                   d.dept_code, e.status AS enrollment_status,
                   a.attendance_id, a.status AS attendance_status,
                   fn_attendance_pct(e.enrollment_id) AS current_attendance_pct
            FROM enrollment e
            JOIN student s ON e.student_id = s.student_id
            JOIN department d ON s.dept_id = d.dept_id
            LEFT JOIN attendance a ON e.enrollment_id = a.enrollment_id AND a.class_date = %s
            WHERE e.offering_id = %s
            ORDER BY s.roll_no ASC
        """
        return db_pool.execute_query(sql, (class_date, offering_id), fetch="all")

    @staticmethod
    def save_batch(offering_id, class_date, records):
        """
        Records attendance for the whole class list in one atomic transaction.
        records: list of dicts [{'enrollment_id': int, 'status': 'Present'|'Absent'|'Late'}]
        """
        with db_pool.get_connection() as conn:
            cur = conn.cursor()
            try:
                if not db_pool.is_mysql:
                    cur.execute("BEGIN IMMEDIATE TRANSACTION;")
                else:
                    cur.execute("START TRANSACTION;")
                    
                for rec in records:
                    enr_id = rec["enrollment_id"]
                    status = rec["status"]
                    
                    # Verify not dropped (enforcing trg_attendance_before_insert rule)
                    cur.execute("SELECT status FROM enrollment WHERE enrollment_id = ?", (enr_id,) if not db_pool.is_mysql else (enr_id,))
                    enr_row = cur.fetchone()
                    if enr_row:
                        current_status = enr_row[0] if not db_pool.is_mysql else enr_row["status"]
                        if current_status == "Dropped":
                            raise ValueError(f"Attendance rejected: Enrollment ID {enr_id} is Dropped.")
                    
                    # Delete existing if any for this day, then insert
                    cur.execute(
                        "DELETE FROM attendance WHERE enrollment_id = ? AND class_date = ?" if not db_pool.is_mysql else
                        "DELETE FROM attendance WHERE enrollment_id = %s AND class_date = %s",
                        (enr_id, class_date)
                    )
                    cur.execute(
                        "INSERT INTO attendance (enrollment_id, class_date, status) VALUES (?, ?, ?)" if not db_pool.is_mysql else
                        "INSERT INTO attendance (enrollment_id, class_date, status) VALUES (%s, %s, %s)",
                        (enr_id, class_date, status)
                    )
                conn.commit()
                return {"success": True, "count": len(records)}
            except Exception as e:
                conn.rollback()
                raise e
            finally:
                cur.close()

    @staticmethod
    def get_summary_by_offering(offering_id):
        sql = """
            SELECT 
                COUNT(a.attendance_id) AS total_logs,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
                COUNT(DISTINCT a.class_date) AS total_classes_conducted
            FROM enrollment e
            JOIN attendance a ON e.enrollment_id = a.enrollment_id
            WHERE e.offering_id = %s
        """
        return db_pool.execute_query(sql, (offering_id,), fetch="one")

