from repositories.db_pool import db_pool

class DashboardRepository:
    @staticmethod
    def get_stats():
        """
        Computes the 6 live KPI cards from database aggregates.
        Zero hardcoded numbers!
        """
        total_students = db_pool.execute_query("SELECT COUNT(*) FROM student", fetch="val") or 0
        total_departments = db_pool.execute_query("SELECT COUNT(*) FROM department", fetch="val") or 0
        active_courses = db_pool.execute_query("SELECT COUNT(DISTINCT course_id) FROM course_offering", fetch="val") or 0
        faculty_members = db_pool.execute_query("SELECT COUNT(*) FROM faculty WHERE status = 'Active'", fetch="val") or 0
        total_enrollments = db_pool.execute_query("SELECT COUNT(*) FROM enrollment WHERE status = 'Enrolled'", fetch="val") or 0
        pending_admissions = db_pool.execute_query("SELECT COUNT(*) FROM admission_application WHERE status = 'Pending'", fetch="val") or 0

        return {
            "total_students": total_students,
            "total_departments": total_departments,
            "active_courses": active_courses,
            "faculty_members": faculty_members,
            "total_enrollments": total_enrollments,
            "pending_admissions": pending_admissions
        }

    @staticmethod
    def get_monthly_chart(year=2026):
        """
        Returns 12-month admissions vs enrollments from SQL aggregates.
        """
        months_abbr = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        admissions = [0] * 12
        enrollments = [0] * 12

        # 1. Admissions by month
        adm_sql = """
            SELECT CAST(strftime('%m', admission_date) AS INTEGER) AS m, COUNT(*) AS cnt
            FROM student
            WHERE strftime('%Y', admission_date) = %s
            GROUP BY m
        """ if not db_pool.is_mysql else """
            SELECT MONTH(admission_date) AS m, COUNT(*) AS cnt
            FROM student
            WHERE YEAR(admission_date) = %s
            GROUP BY m
        """
        adm_rows = db_pool.execute_query(adm_sql, (str(year),), fetch="all")
        for r in adm_rows:
            m_idx = (r.get("m") or 1) - 1
            if 0 <= m_idx < 12:
                admissions[m_idx] = r.get("cnt") or 0

        # 2. Enrollments by month
        enr_sql = """
            SELECT CAST(strftime('%m', enroll_date) AS INTEGER) AS m, COUNT(*) AS cnt
            FROM enrollment
            WHERE strftime('%Y', enroll_date) = %s
            GROUP BY m
        """ if not db_pool.is_mysql else """
            SELECT MONTH(enroll_date) AS m, COUNT(*) AS cnt
            FROM enrollment
            WHERE YEAR(enroll_date) = %s
            GROUP BY m
        """
        enr_rows = db_pool.execute_query(enr_sql, (str(year),), fetch="all")
        for r in enr_rows:
            m_idx = (r.get("m") or 1) - 1
            if 0 <= m_idx < 12:
                enrollments[m_idx] = r.get("cnt") or 0

        return {
            "labels": months_abbr,
            "admissions": admissions,
            "enrollments": enrollments
        }

