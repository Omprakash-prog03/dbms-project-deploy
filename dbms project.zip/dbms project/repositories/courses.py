from repositories.db_pool import db_pool

class CourseRepository:
    @staticmethod
    def get_all(dept_id=None, semester_no=None):
        where_clauses = ["1=1"]
        params = []
        if dept_id:
            where_clauses.append("c.dept_id = %s")
            params.append(dept_id)
        if semester_no:
            where_clauses.append("c.semester_no = %s")
            params.append(semester_no)
        where_sql = " AND ".join(where_clauses)
        
        sql = f"""
            SELECT c.*, d.dept_code, d.dept_name,
                   COUNT(DISTINCT co.offering_id) AS total_offerings
            FROM course c
            JOIN department d ON c.dept_id = d.dept_id
            LEFT JOIN course_offering co ON c.course_id = co.course_id
            WHERE {where_sql}
            GROUP BY c.course_id
            ORDER BY c.course_code ASC
        """
        return db_pool.execute_query(sql, tuple(params), fetch="all")

    @staticmethod
    def get_by_id(course_id):
        sql = """
            SELECT c.*, d.dept_code, d.dept_name
            FROM course c
            JOIN department d ON c.dept_id = d.dept_id
            WHERE c.course_id = %s
        """
        return db_pool.execute_query(sql, (course_id,), fetch="one")

    @staticmethod
    def create(course_code, title, credits, dept_id, semester_no):
        sql = """
            INSERT INTO course (course_code, title, credits, dept_id, semester_no)
            VALUES (%s, %s, %s, %s, %s)
        """
        params = (course_code, title, credits, dept_id, semester_no)
        return db_pool.execute_dml(sql, params)["lastrowid"]

    @staticmethod
    def get_offerings(academic_year="2025-2026", term=None):
        where_clauses = ["1=1"]
        params = []
        if academic_year:
            where_clauses.append("co.academic_year = %s")
            params.append(academic_year)
        if term:
            where_clauses.append("co.term = %s")
            params.append(term)
        where_sql = " AND ".join(where_clauses)
        
        sql = f"""
            SELECT co.offering_id, co.course_id, co.faculty_id, co.academic_year, co.term,
                   co.capacity, co.enrolled_count,
                   c.course_code, c.title AS course_title, c.credits,
                   d.dept_code, d.dept_name,
                   (f.first_name || ' ' || f.last_name) AS instructor_name,
                   ROUND((CAST(co.enrolled_count AS REAL) / co.capacity) * 100, 1) AS utilization_pct,
                   CASE 
                       WHEN co.enrolled_count >= co.capacity THEN 'FULL'
                       WHEN co.enrolled_count >= (co.capacity * 0.8) THEN 'ALMOST FULL'
                       ELSE 'AVAILABLE'
                   END AS seat_status
            FROM course_offering co
            JOIN course c ON co.course_id = c.course_id
            JOIN department d ON c.dept_id = d.dept_id
            JOIN faculty f ON co.faculty_id = f.faculty_id
            WHERE {where_sql}
            ORDER BY c.course_code ASC
        """
        return db_pool.execute_query(sql, tuple(params), fetch="all")

    @staticmethod
    def get_offering_by_id(offering_id):
        sql = """
            SELECT co.*, c.course_code, c.title AS course_title, c.credits,
                   d.dept_code, d.dept_name,
                   (f.first_name || ' ' || f.last_name) AS instructor_name
            FROM course_offering co
            JOIN course c ON co.course_id = c.course_id
            JOIN department d ON c.dept_id = d.dept_id
            JOIN faculty f ON co.faculty_id = f.faculty_id
            WHERE co.offering_id = %s
        """
        return db_pool.execute_query(sql, (offering_id,), fetch="one")

    @staticmethod
    def create_offering(course_id, faculty_id, academic_year, term, capacity):
        sql = """
            INSERT INTO course_offering (course_id, faculty_id, academic_year, term, capacity, enrolled_count)
            VALUES (%s, %s, %s, %s, %s, 0)
        """
        params = (course_id, faculty_id, academic_year, term, capacity)
        return db_pool.execute_dml(sql, params)["lastrowid"]

