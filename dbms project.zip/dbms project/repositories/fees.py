from repositories.db_pool import db_pool
import datetime

class FeeRepository:
    @staticmethod
    def get_all_payments(student_id=None, semester_no=None):
        where_clauses = ["1=1"]
        params = []
        if student_id:
            where_clauses.append("fp.student_id = %s")
            params.append(student_id)
        if semester_no:
            where_clauses.append("fp.semester_no = %s")
            params.append(semester_no)
        where_sql = " AND ".join(where_clauses)
        
        sql = f"""
            SELECT fp.*, s.roll_no, 
                   (s.first_name || ' ' || s.last_name) AS student_name,
                   d.dept_code
            FROM fee_payment fp
            JOIN student s ON fp.student_id = s.student_id
            JOIN department d ON s.dept_id = d.dept_id
            WHERE {where_sql}
            ORDER BY fp.paid_on DESC, fp.payment_id DESC
        """
        return db_pool.execute_query(sql, tuple(params), fetch="all")

    @staticmethod
    def get_defaulters():
        sql = """
            SELECT * FROM v_fee_status
            WHERE is_defaulter = 1
            ORDER BY balance_due DESC
        """
        return db_pool.execute_query(sql, fetch="all")

    @staticmethod
    def get_unpaid_students():
        sql = """
            SELECT * FROM v_fee_status
            WHERE payment_status = 'Unpaid'
            ORDER BY dept_code ASC, roll_no ASC
        """
        return db_pool.execute_query(sql, fetch="all")

    @staticmethod
    def get_fee_structures():
        sql = """
            SELECT fs.*, d.dept_code, d.dept_name
            FROM fee_structure fs
            JOIN department d ON fs.dept_id = d.dept_id
            ORDER BY d.dept_code ASC, fs.semester_no ASC
        """
        return db_pool.execute_query(sql, fetch="all")

    @staticmethod
    def get_missing_fee_structures():
        """
        Relational anti-join listing departments and semesters (1-8)
        that currently have NO fee structure configured in the database.
        """
        sql = """
            WITH RECURSIVE sem_seq(sem_no) AS (
                SELECT 1
                UNION ALL
                SELECT sem_no + 1 FROM sem_seq WHERE sem_no < 8
            )
            SELECT d.dept_id, d.dept_code, d.dept_name, s.sem_no AS semester_no
            FROM department d
            CROSS JOIN sem_seq s
            LEFT JOIN fee_structure fs ON d.dept_id = fs.dept_id AND s.sem_no = fs.semester_no
            WHERE fs.amount IS NULL
            ORDER BY d.dept_code ASC, s.sem_no ASC
        """
        return db_pool.execute_query(sql, fetch="all")

    @staticmethod
    def set_fee_structure(dept_id, semester_no, amount):
        amount = float(amount)
        if amount <= 0:
            raise ValueError("Fee amount must be strictly greater than zero (CHECK amount > 0).")
        
        existing = db_pool.execute_query(
            "SELECT amount FROM fee_structure WHERE dept_id = %s AND semester_no = %s",
            (dept_id, semester_no),
            fetch="one"
        )
        if existing:
            sql = "UPDATE fee_structure SET amount = %s WHERE dept_id = %s AND semester_no = %s"
            db_pool.execute_dml(sql, (amount, dept_id, semester_no))
        else:
            sql = "INSERT INTO fee_structure (dept_id, semester_no, amount) VALUES (%s, %s, %s)"
            db_pool.execute_dml(sql, (dept_id, semester_no, amount))
        return True

    @staticmethod
    def record_payment(student_id, semester_no, amount, mode, receipt_no):
        """
        Invokes sp_record_payment with overpayment protection.
        """
        amount = float(amount)
        if amount <= 0:
            return {"status_code": 400, "message": "Payment amount must be greater than zero."}

        with db_pool.get_connection() as conn:
            cur = conn.cursor()
            try:
                if not db_pool.is_mysql:
                    cur.execute("BEGIN IMMEDIATE TRANSACTION;")
                else:
                    cur.execute("START TRANSACTION;")

                # 1. Lookup student dept
                cur.execute(
                    "SELECT dept_id FROM student WHERE student_id = ?" if not db_pool.is_mysql else
                    "SELECT dept_id FROM student WHERE student_id = %s",
                    (student_id,)
                )
                stu = cur.fetchone()
                if not stu:
                    conn.rollback()
                    return {"status_code": 404, "message": "Student does not exist."}
                dept_id = stu[0] if not db_pool.is_mysql else stu["dept_id"]

                # 2. Lookup fee structure
                cur.execute(
                    "SELECT amount FROM fee_structure WHERE dept_id = ? AND semester_no = ?" if not db_pool.is_mysql else
                    "SELECT amount FROM fee_structure WHERE dept_id = %s AND semester_no = %s",
                    (dept_id, semester_no)
                )
                fee_row = cur.fetchone()
                if not fee_row:
                    conn.rollback()
                    return {"status_code": 404, "message": "Fee structure not configured for this semester."}
                sem_fee = float(fee_row[0] if not db_pool.is_mysql else fee_row["amount"])

                # 3. Calculate currently paid
                cur.execute(
                    "SELECT COALESCE(SUM(amount), 0) FROM fee_payment WHERE student_id = ? AND semester_no = ?" if not db_pool.is_mysql else
                    "SELECT COALESCE(SUM(amount), 0) FROM fee_payment WHERE student_id = %s AND semester_no = %s",
                    (student_id, semester_no)
                )
                already_paid = float((cur.fetchone()[0]) if not db_pool.is_mysql else list(cur.fetchone().values())[0])
                max_payable = sem_fee - already_paid

                if amount > max_payable:
                    conn.rollback()
                    return {"status_code": 400, "message": f"Overpayment rejected. Maximum remaining fee payable: {max_payable:.2f}"}

                # 4. Insert payment
                paid_on = datetime.date.today().isoformat()
                cur.execute(
                    "INSERT INTO fee_payment (student_id, semester_no, amount, paid_on, mode, receipt_no) VALUES (?, ?, ?, ?, ?, ?)" if not db_pool.is_mysql else
                    "INSERT INTO fee_payment (student_id, semester_no, amount, paid_on, mode, receipt_no) VALUES (%s, %s, %s, %s, %s, %s)",
                    (student_id, semester_no, amount, paid_on, mode, receipt_no)
                )
                payment_id = cur.lastrowid

                # 5. Audit log
                audit_json = db_pool._json_object("student_id", student_id, "semester", semester_no, "amount", amount, "receipt", receipt_no)
                cur.execute(
                    "INSERT INTO audit_log (table_name, action, record_id, new_values, changed_by) VALUES (?, 'INSERT', ?, ?, 'fee_clerk')" if not db_pool.is_mysql else
                    "INSERT INTO audit_log (table_name, action, record_id, new_values, changed_by) VALUES ('fee_payment', 'INSERT', %s, %s, 'fee_clerk')",
                    ("fee_payment", payment_id, audit_json) if not db_pool.is_mysql else (payment_id, audit_json)
                )

                conn.commit()
                return {"status_code": 200, "message": "Payment successfully recorded.", "payment_id": payment_id}
            except Exception as e:
                conn.rollback()
                return {"status_code": 500, "message": f"Payment recording failed: {str(e)}"}
            finally:
                cur.close()

