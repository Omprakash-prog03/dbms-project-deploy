from repositories.db_pool import db_pool
import datetime
import bcrypt

class AdmissionsRepository:
    @staticmethod
    def get_pending():
        sql = """
            SELECT aa.*, d.dept_code, d.dept_name
            FROM admission_application aa
            JOIN department d ON aa.dept_id = d.dept_id
            WHERE aa.status = 'Pending'
            ORDER BY aa.applied_on ASC
        """
        return db_pool.execute_query(sql, fetch="all")

    @staticmethod
    def create_application(applicant_name, email, phone, dept_id):
        sql = """
            INSERT INTO admission_application (applicant_name, email, phone, dept_id, applied_on, status)
            VALUES (%s, %s, %s, %s, %s, 'Pending')
        """
        applied_on = datetime.date.today().isoformat()
        return db_pool.execute_dml(sql, (applicant_name, email, phone, dept_id, applied_on))["lastrowid"]

    @staticmethod
    def approve_admission(application_id, reviewer_id=1):
        """
        Implements sp_approve_admission transactional logic.
        """
        with db_pool.get_connection() as conn:
            cur = conn.cursor()
            try:
                if not db_pool.is_mysql:
                    cur.execute("BEGIN IMMEDIATE TRANSACTION;")
                else:
                    cur.execute("START TRANSACTION;")

                # Step 1: Check application
                cur.execute(
                    "SELECT applicant_name, email, phone, dept_id, status FROM admission_application WHERE application_id = ?" if not db_pool.is_mysql else
                    "SELECT applicant_name, email, phone, dept_id, status FROM admission_application WHERE application_id = %s FOR UPDATE",
                    (application_id,)
                )
                app_row = cur.fetchone()
                if not app_row:
                    conn.rollback()
                    return {"status_code": 404, "message": "Admission application not found."}
                
                name = app_row[0] if not db_pool.is_mysql else app_row["applicant_name"]
                email = app_row[1] if not db_pool.is_mysql else app_row["email"]
                phone = app_row[2] if not db_pool.is_mysql else app_row["phone"]
                dept_id = app_row[3] if not db_pool.is_mysql else app_row["dept_id"]
                status = app_row[4] if not db_pool.is_mysql else app_row["status"]

                if status != "Pending":
                    conn.rollback()
                    return {"status_code": 400, "message": f"Application cannot be processed. Current status: {status}"}

                # Parse name
                name_parts = name.strip().split(" ", 1)
                first_name = name_parts[0]
                last_name = name_parts[1] if len(name_parts) > 1 else "Scholar"

                # Generate Roll No: YY + DEPT_CODE + SEQ
                cur.execute(
                    "SELECT dept_code FROM department WHERE dept_id = ?" if not db_pool.is_mysql else
                    "SELECT dept_code FROM department WHERE dept_id = %s",
                    (dept_id,)
                )
                dept_code = (cur.fetchone()[0]) if not db_pool.is_mysql else cur.fetchone()["dept_code"]
                year_suffix = datetime.date.today().strftime("%y")

                cur.execute(
                    "SELECT COUNT(*) + 1 FROM student WHERE dept_id = ?" if not db_pool.is_mysql else
                    "SELECT COUNT(*) + 1 FROM student WHERE dept_id = %s",
                    (dept_id,)
                )
                seq_num = (cur.fetchone()[0]) if not db_pool.is_mysql else list(cur.fetchone().values())[0]
                roll_no = f"{year_suffix}{dept_code}{int(seq_num):03d}"

                # Insert Student
                today = datetime.date.today().isoformat()
                dob = (datetime.date.today() - datetime.timedelta(days=18*365)).isoformat()
                cur.execute(
                    """INSERT INTO student (
                        roll_no, first_name, last_name, email, phone, dob, gender,
                        address, dept_id, admission_date, current_semester, status
                    ) VALUES (?, ?, ?, ?, ?, ?, 'Other', 'Hostel Block A', ?, ?, 1, 'Active')""" if not db_pool.is_mysql else
                    """INSERT INTO student (
                        roll_no, first_name, last_name, email, phone, dob, gender,
                        address, dept_id, admission_date, current_semester, status
                    ) VALUES (%s, %s, %s, %s, %s, %s, 'Other', 'Hostel Block A', %s, %s, 1, 'Active')""",
                    (roll_no, first_name, last_name, email, phone, dob, dept_id, today)
                )
                student_id = cur.lastrowid

                # Provision user account
                pw_hash = bcrypt.hashpw(b"student123", bcrypt.gensalt()).decode("utf-8")
                cur.execute(
                    "INSERT INTO app_user (username, password_hash, role, student_id) VALUES (?, ?, 'student', ?)" if not db_pool.is_mysql else
                    "INSERT INTO app_user (username, password_hash, role, student_id) VALUES (%s, %s, 'student', %s)",
                    (roll_no.lower(), pw_hash, student_id)
                )

                # Update application status
                now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cur.execute(
                    "UPDATE admission_application SET status = 'Approved', reviewed_by = ?, reviewed_on = ? WHERE application_id = ?" if not db_pool.is_mysql else
                    "UPDATE admission_application SET status = 'Approved', reviewed_by = %s, reviewed_on = %s WHERE application_id = %s",
                    (reviewer_id, now_str, application_id)
                )

                # Audit log
                audit_json = db_pool._json_object("status", "Approved", "student_id", student_id, "roll_no", roll_no)
                cur.execute(
                    "INSERT INTO audit_log (table_name, action, record_id, new_values, changed_by) VALUES ('admission_application', 'UPDATE', ?, ?, 'admissions_officer')" if not db_pool.is_mysql else
                    "INSERT INTO audit_log (table_name, action, record_id, new_values, changed_by) VALUES ('admission_application', 'UPDATE', %s, %s, 'admissions_officer')",
                    (application_id, audit_json)
                )

                conn.commit()
                return {
                    "status_code": 200,
                    "message": "Admission approved, student enrolled, and login provisioned.",
                    "student_id": student_id,
                    "roll_no": roll_no
                }
            except Exception as e:
                conn.rollback()
                return {"status_code": 500, "message": f"Transaction aborted: {str(e)}"}
            finally:
                cur.close()

    @staticmethod
    def reject_admission(application_id, reviewer_id=1):
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sql = "UPDATE admission_application SET status = 'Rejected', reviewed_by = %s, reviewed_on = %s WHERE application_id = %s"
        db_pool.execute_dml(sql, (reviewer_id, now_str, application_id))
        return {"status_code": 200, "message": "Application rejected."}

