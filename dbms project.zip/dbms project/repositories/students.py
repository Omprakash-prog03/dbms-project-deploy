from repositories.db_pool import db_pool

class StudentRepository:
    # Allow-listed columns for safe sorting
    ALLOWED_SORT_COLUMNS = {
        "roll_no": "s.roll_no",
        "name": "full_name",
        "dept_code": "d.dept_code",
        "current_semester": "s.current_semester",
        "status": "s.status",
        "admission_date": "s.admission_date",
        "average_marks": "average_marks"
    }

    @staticmethod
    def get_all(search=None, dept_id=None, status=None, sort_col="roll_no", sort_dir="asc", page=1, per_page=15):
        # Validate sort column and direction against allowlists
        order_col = StudentRepository.ALLOWED_SORT_COLUMNS.get(sort_col, "s.roll_no")
        order_dir = "ASC" if str(sort_dir).upper() == "ASC" else "DESC"
        
        where_clauses = ["1=1"]
        params = []
        
        if search:
            where_clauses.append("(s.roll_no LIKE %s OR s.first_name LIKE %s OR s.last_name LIKE %s OR s.email LIKE %s)")
            like_term = f"%{search}%"
            params.extend([like_term, like_term, like_term, like_term])
            
        if dept_id:
            where_clauses.append("s.dept_id = %s")
            params.append(dept_id)
            
        if status and status != "All":
            where_clauses.append("s.status = %s")
            params.append(status)
            
        where_sql = " AND ".join(where_clauses)
        
        # Count total matching rows
        count_sql = f"""
            SELECT COUNT(*)
            FROM student s
            JOIN department d ON s.dept_id = d.dept_id
            WHERE {where_sql}
        """
        total = db_pool.execute_query(count_sql, tuple(params), fetch="val") or 0
        
        # Paginated fetch from v_student_overview
        offset = (page - 1) * per_page
        query_sql = f"""
            SELECT 
                s.student_id,
                s.roll_no,
                s.first_name,
                s.last_name,
                (s.first_name || ' ' || s.last_name) AS full_name,
                s.email,
                s.phone,
                s.gender,
                s.current_semester,
                s.status,
                s.admission_date,
                d.dept_id,
                d.dept_code,
                d.dept_name,
                COUNT(DISTINCT e.offering_id) AS total_courses_enrolled,
                ROUND(COALESCE(AVG(r.marks_obtained), 0), 2) AS average_marks
            FROM student s
            JOIN department d ON s.dept_id = d.dept_id
            LEFT JOIN enrollment e ON s.student_id = e.student_id AND e.status = 'Enrolled'
            LEFT JOIN result r ON e.enrollment_id = r.enrollment_id
            WHERE {where_sql}
            GROUP BY s.student_id, d.dept_id, s.admission_date
            ORDER BY {order_col} {order_dir}
            LIMIT %s OFFSET %s
        """
        page_params = tuple(params + [per_page, offset])
        rows = db_pool.execute_query(query_sql, page_params, fetch="all")
        
        return {
            "items": rows,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page if total > 0 else 1
        }

    @staticmethod
    def get_by_id(student_id):
        sql = """
            SELECT s.*, d.dept_code, d.dept_name,
                   (s.first_name || ' ' || s.last_name) AS full_name,
                   fn_student_cgpa(s.student_id) AS cgpa
            FROM student s
            JOIN department d ON s.dept_id = d.dept_id
            WHERE s.student_id = %s
        """
        return db_pool.execute_query(sql, (student_id,), fetch="one")

    @staticmethod
    def get_by_roll_no(roll_no):
        sql = """
            SELECT s.*, d.dept_code, d.dept_name,
                   (s.first_name || ' ' || s.last_name) AS full_name,
                   fn_student_cgpa(s.student_id) AS cgpa
            FROM student s
            JOIN department d ON s.dept_id = d.dept_id
            WHERE s.roll_no = %s
        """
        return db_pool.execute_query(sql, (roll_no,), fetch="one")

    @staticmethod
    def get_guardians(student_id):
        sql = "SELECT * FROM guardian WHERE student_id = %s ORDER BY guardian_id ASC"
        return db_pool.execute_query(sql, (student_id,), fetch="all")

    @staticmethod
    def get_enrollments(student_id):
        sql = """
            SELECT e.enrollment_id, e.enroll_date, e.status AS enrollment_status, e.status,
                   co.offering_id, co.academic_year, co.term,
                   c.course_code, c.title AS course_title, c.title, c.credits, c.semester_no,
                   (f.first_name || ' ' || f.last_name) AS instructor_name,
                   (f.first_name || ' ' || f.last_name) AS faculty_name,
                   fn_attendance_pct(e.enrollment_id) AS attendance_percentage,
                   fn_attendance_pct(e.enrollment_id) AS attendance_pct
            FROM enrollment e
            JOIN course_offering co ON e.offering_id = co.offering_id
            JOIN course c ON co.course_id = c.course_id
            JOIN faculty f ON co.faculty_id = f.faculty_id
            WHERE e.student_id = %s
            ORDER BY co.academic_year DESC, c.course_code ASC
        """
        return db_pool.execute_query(sql, (student_id,), fetch="all")

    @staticmethod
    def get_results(student_id):
        sql = """
            SELECT c.course_code, c.title AS course_title, c.title,
                   ex.exam_type, ex.max_marks, r.marks_obtained,
                   ROUND((r.marks_obtained / ex.max_marks) * 100, 1) AS percentage,
                   fn_grade(ROUND((r.marks_obtained / ex.max_marks) * 100, 1)) AS grade
            FROM enrollment e
            JOIN course_offering co ON e.offering_id = co.offering_id
            JOIN course c ON co.course_id = c.course_id
            JOIN exam ex ON co.offering_id = ex.offering_id
            JOIN result r ON ex.exam_id = r.exam_id AND e.enrollment_id = r.enrollment_id
            WHERE e.student_id = %s
            ORDER BY c.course_code ASC, ex.exam_type ASC
        """
        return db_pool.execute_query(sql, (student_id,), fetch="all")

    @staticmethod
    def get_fee_summary(student_id):
        sql = """
            SELECT 
                fs.semester_no,
                fs.amount AS total_fee,
                COALESCE(SUM(fp.amount), 0) AS total_paid,
                (fs.amount - COALESCE(SUM(fp.amount), 0)) AS balance_due,
                CASE 
                    WHEN (fs.amount - COALESCE(SUM(fp.amount), 0)) > 0 THEN 1 
                    ELSE 0 
                END AS is_defaulter,
                CASE 
                    WHEN COALESCE(SUM(fp.amount), 0) >= fs.amount THEN 'Fully Paid'
                    WHEN COALESCE(SUM(fp.amount), 0) > 0 THEN 'Partial'
                    ELSE 'Unpaid'
                END AS payment_status
            FROM student s
            JOIN department d ON s.dept_id = d.dept_id
            JOIN fee_structure fs ON d.dept_id = fs.dept_id AND fs.semester_no <= s.current_semester
            LEFT JOIN fee_payment fp ON s.student_id = fp.student_id AND fs.semester_no = fp.semester_no
            WHERE s.student_id = %s
            GROUP BY s.student_id, fs.semester_no, fs.amount
            ORDER BY fs.semester_no ASC
        """
        return db_pool.execute_query(sql, (student_id,), fetch="all")

    @staticmethod
    def create(roll_no, first_name, last_name, email, phone, dob, gender, address, dept_id, admission_date, current_semester=1, status='Active', photo_url=None):
        sql = """
            INSERT INTO student (
                roll_no, first_name, last_name, email, phone,
                dob, gender, address, dept_id, admission_date,
                current_semester, status, photo_url
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        params = (roll_no, first_name, last_name, email, phone, dob, gender, address, dept_id, admission_date, current_semester, status, photo_url)
        res = db_pool.execute_dml(sql, params)
        
        # Log to audit table
        audit_sql = """
            INSERT INTO audit_log (table_name, action, record_id, new_values, changed_by)
            VALUES (%s, %s, %s, %s, %s)
        """
        db_pool.execute_dml(audit_sql, (
            "student", "INSERT", res["lastrowid"],
            db_pool._json_object("roll_no", roll_no, "name", f"{first_name} {last_name}"),
            "admin_ui"
        ))
        return res["lastrowid"]

    @staticmethod
    def update(student_id, first_name, last_name, email, phone, address, current_semester, status):
        # Fetch old state for audit
        old = StudentRepository.get_by_id(student_id)
        sql = """
            UPDATE student
            SET first_name = %s, last_name = %s, email = %s, phone = %s,
                address = %s, current_semester = %s, status = %s
            WHERE student_id = %s
        """
        params = (first_name, last_name, email, phone, address, current_semester, status, student_id)
        res = db_pool.execute_dml(sql, params)
        
        if old:
            audit_sql = """
                INSERT INTO audit_log (table_name, action, record_id, old_values, new_values, changed_by)
                VALUES (%s, %s, %s, %s, %s)
            """
            db_pool.execute_dml(audit_sql, (
                "student", "UPDATE", student_id,
                db_pool._json_object("status", old["status"], "current_semester", old["current_semester"]),
                db_pool._json_object("status", status, "current_semester", current_semester),
                "admin_ui"
            ))
        return res["rowcount"]

    @staticmethod
    def delete(student_id):
        old = StudentRepository.get_by_id(student_id)
        sql = "DELETE FROM student WHERE student_id = %s"
        res = db_pool.execute_dml(sql, (student_id,))
        if old:
            audit_sql = """
                INSERT INTO audit_log (table_name, action, record_id, old_values, changed_by)
                VALUES (%s, %s, %s, %s, %s)
            """
            db_pool.execute_dml(audit_sql, (
                "student", "DELETE", student_id,
                db_pool._json_object("roll_no", old["roll_no"], "name", old["full_name"]),
                "admin_ui"
            ))
        return res["rowcount"]
